-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th5 18, 2021 lúc 01:31 AM
-- Phiên bản máy phục vụ: 10.4.13-MariaDB
-- Phiên bản PHP: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `quanly_banhang`
--

DELIMITER $$
--
-- Thủ tục
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `themmoi_hanghoa` (`ma` VARCHAR(15), `ten` VARCHAR(30), `mota` VARCHAR(1000), `ma_qg` VARCHAR(15))  begin
	insert into hang_hoa (mahang, tenhang, mota, xuatxuid) values (ma, ten, mota, ma_qg);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `themmoi_hoadon_ban` (`mahd` VARCHAR(15), `ten` VARCHAR(30), `mt` VARCHAR(1000), `ngay` DATE, `ma_kh` VARCHAR(15))  begin
	insert into hoa_don_ban values (mahd, ten, mt, ngay, ma_kh);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `themmoi_hoadon_ban_chitiet` (`mahd` VARCHAR(15), `ma_hang` VARCHAR(15), `sl` FLOAT, `gia` FLOAT)  begin
	insert into hoa_don_ban_chi_tiet values (mahd, ma_hang, sl, gia);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `themmoi_hoadon_mua` (`mahd` VARCHAR(15), `ten` VARCHAR(30), `mt` VARCHAR(1000), `ngay` DATE)  begin
	insert into hoa_don_mua values (mahd, ten, mt, ngay);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `themmoi_hoadon_mua_chitiet` (`mahd` VARCHAR(15), `ma_hang` VARCHAR(15), `sl` FLOAT, `gia` FLOAT)  begin
	insert into hoa_don_mua_chi_tiet values (mahd, ma_hang, sl, gia);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `themmoi_khachhang` (`ma` VARCHAR(15), `ten` VARCHAR(50), `dt` VARCHAR(11), `mail` VARCHAR(50), `dc` VARCHAR(500), `loai` VARCHAR(15))  begin
	insert into khach_hang values (ma, ten, dt, mail, dc, loai);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `themmoi_loai_khachhang` (`ma` VARCHAR(15), `ten` VARCHAR(50))  begin
	insert into loai_khach_hang values (ma, ten);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `themmoi_quocgia` (`ma` VARCHAR(15), `ten` VARCHAR(50))  begin
	insert into quoc_gia (maquocgia, tenquocgia) values (ma, ten);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `thongke_soluong_ban` ()  begin
	select mahang as Ma_Hang, sum(soluong) as Soluong_Ban from hoa_don_ban_chi_tiet group by mahang;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `thongke_soluong_nhap` ()  begin
	select mahang as Ma_Hang, sum(soluong) as Soluong_Nhap from hoa_don_mua_chi_tiet group by mahang;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `thongke_tonkho` ()  begin
	select sln.ma_hang, soluong_nhap, gia_mua, ifnull(soluong_ban, 0) as soluong_ban, ifnull(gia_ban, 0) as gia_ban, (soluong_nhap - ifnull(soluong_ban, 0)) as Ton_Kho, round(ifnull(gia_ban, -0) - ifnull(soluong_ban, 0) * gia_mua / soluong_nhap) as Loi_Nhuan from vSoLuongNhap as sln left join vSoLuongBan as slb on sln.ma_hang = slb.ma_hang; 
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `thongtin_chitiet` (`ten_bang` VARCHAR(50))  begin
    set @cmd = concat('select * from ', ten_bang);
	prepare stm1 from @cmd;
	execute stm1;
    deallocate prepare stm1;
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hang_hoa`
--

CREATE TABLE `hang_hoa` (
  `MaHang` varchar(15) NOT NULL,
  `TenHang` varchar(50) DEFAULT NULL,
  `MoTa` varchar(300) DEFAULT NULL,
  `XuatXuID` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `hang_hoa`
--

INSERT INTO `hang_hoa` (`MaHang`, `TenHang`, `MoTa`, `XuatXuID`) VALUES
('IP10', 'iPhone 10', '', 'CN'),
('IP11', 'iPhone 11 Plus', '', 'CN'),
('IP12', 'iPhone 12 Max', '', 'CN'),
('MB1', 'Macbook Pro M1', '', 'CN');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoa_don_ban`
--

CREATE TABLE `hoa_don_ban` (
  `MaHoaDon` varchar(15) NOT NULL,
  `TenHoaDon` varchar(200) DEFAULT NULL,
  `MoTa` varchar(500) DEFAULT NULL,
  `NgayBan` timestamp NOT NULL DEFAULT current_timestamp(),
  `MaKhachHang` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `hoa_don_ban`
--

INSERT INTO `hoa_don_ban` (`MaHoaDon`, `TenHoaDon`, `MoTa`, `NgayBan`, `MaKhachHang`) VALUES
('HD001', 'Bán iphone các loại', '', '2020-03-04 17:00:00', 'KH1'),
('HD002', 'Bán Macbook các loại', '', '2020-03-06 17:00:00', 'KH2'),
('HD003', 'Bán Iphone 12', '', '2020-03-11 17:00:00', 'KH3');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoa_don_ban_chi_tiet`
--

CREATE TABLE `hoa_don_ban_chi_tiet` (
  `MaHoaDon` varchar(15) DEFAULT NULL,
  `MaHang` varchar(15) DEFAULT NULL,
  `SoLuong` int(11) DEFAULT NULL,
  `GiaBan` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `hoa_don_ban_chi_tiet`
--

INSERT INTO `hoa_don_ban_chi_tiet` (`MaHoaDon`, `MaHang`, `SoLuong`, `GiaBan`) VALUES
('HD001', 'IP10', 10, 5000),
('HD001', 'IP11', 8, 5000),
('HD002', 'MB1', 3, 10000),
('HD001', 'IP11', 5, 10000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoa_don_mua`
--

CREATE TABLE `hoa_don_mua` (
  `MaHoaDon` varchar(15) NOT NULL,
  `TenHoaDon` varchar(50) DEFAULT NULL,
  `MoTa` varchar(300) DEFAULT NULL,
  `NgayMua` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `hoa_don_mua`
--

INSERT INTO `hoa_don_mua` (`MaHoaDon`, `TenHoaDon`, `MoTa`, `NgayMua`) VALUES
('HD001', 'Nhập iphone các loại', '', '2020-03-02 17:00:00'),
('HD002', 'Nhập Macbook các loại', '', '2020-03-04 17:00:00'),
('HD003', 'Nhập Iphone 12', '', '2020-03-09 17:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoa_don_mua_chi_tiet`
--

CREATE TABLE `hoa_don_mua_chi_tiet` (
  `MaHoaDon` varchar(15) DEFAULT NULL,
  `MaHang` varchar(15) DEFAULT NULL,
  `SoLuong` int(11) DEFAULT NULL,
  `GiaMua` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `hoa_don_mua_chi_tiet`
--

INSERT INTO `hoa_don_mua_chi_tiet` (`MaHoaDon`, `MaHang`, `SoLuong`, `GiaMua`) VALUES
('HD001', 'IP10', 50, 10000000),
('HD002', 'IP11', 50, 20000000),
('HD001', 'IP11', 50, 15000000),
('HD001', 'IP12', 20, 20000000),
('HD003', 'IP12', 60, 25000000),
('HD003', 'IP11', 20, 30000000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `khach_hang`
--

CREATE TABLE `khach_hang` (
  `MaKhachHang` varchar(15) NOT NULL,
  `TenKhachHang` varchar(50) DEFAULT NULL,
  `DienThoai` varchar(11) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `DiaChi` varchar(250) DEFAULT NULL,
  `LoaiKhachHang` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `khach_hang`
--

INSERT INTO `khach_hang` (`MaKhachHang`, `TenKhachHang`, `DienThoai`, `Email`, `DiaChi`, `LoaiKhachHang`) VALUES
('KH1', 'Nguyễn Văn An', '0350123456', 'an.nguyenvan@gmail.com', 'Hà Nội', 'VIP1'),
('KH2', 'Lê Thu Minh', '0350142351', 'minh.lethu@gmail.com', 'Vĩnh Phúc', 'VIP2'),
('KH3', 'Trần Trọng Nghĩa', '0334846791', 'nghia.trantrong@gmail.com', 'Hà Nam', 'VIP2');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loai_khach_hang`
--

CREATE TABLE `loai_khach_hang` (
  `MaLoai` varchar(15) NOT NULL,
  `TenLoai` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `loai_khach_hang`
--

INSERT INTO `loai_khach_hang` (`MaLoai`, `TenLoai`) VALUES
('VIP1', ''),
('VIP2', ''),
('VIP3', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `quoc_gia`
--

CREATE TABLE `quoc_gia` (
  `MaQuocGia` varchar(15) NOT NULL,
  `TenQuocGia` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `quoc_gia`
--

INSERT INTO `quoc_gia` (`MaQuocGia`, `TenQuocGia`) VALUES
('CN', 'Trung Quốc'),
('ENG', 'Anh'),
('THA', 'Thái Lan'),
('US', 'Mỹ'),
('VN', 'Việt Nam');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `test_table`
--

CREATE TABLE `test_table` (
  `ma_khach_hang` varchar(15) DEFAULT NULL,
  `ma_hoa_don` varchar(15) DEFAULT NULL,
  `ma_hang_hoa` varchar(15) DEFAULT NULL,
  `ma_quoc_gia` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc đóng vai cho view `vsoluongban`
-- (See below for the actual view)
--
CREATE TABLE `vsoluongban` (
`Ma_Hang` varchar(15)
,`SoLuong_Ban` decimal(32,0)
,`Gia_Ban` float
);

-- --------------------------------------------------------

--
-- Cấu trúc đóng vai cho view `vsoluongnhap`
-- (See below for the actual view)
--
CREATE TABLE `vsoluongnhap` (
`Ma_Hang` varchar(15)
,`SoLuong_Nhap` decimal(32,0)
,`Gia_Mua` float
);

-- --------------------------------------------------------

--
-- Cấu trúc cho view `vsoluongban`
--
DROP TABLE IF EXISTS `vsoluongban`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vsoluongban`  AS SELECT `hoa_don_ban_chi_tiet`.`MaHang` AS `Ma_Hang`, ifnull(sum(`hoa_don_ban_chi_tiet`.`SoLuong`),0) AS `SoLuong_Ban`, `hoa_don_ban_chi_tiet`.`GiaBan` AS `Gia_Ban` FROM `hoa_don_ban_chi_tiet` GROUP BY `hoa_don_ban_chi_tiet`.`MaHang` ;

-- --------------------------------------------------------

--
-- Cấu trúc cho view `vsoluongnhap`
--
DROP TABLE IF EXISTS `vsoluongnhap`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vsoluongnhap`  AS SELECT `hoa_don_mua_chi_tiet`.`MaHang` AS `Ma_Hang`, sum(`hoa_don_mua_chi_tiet`.`SoLuong`) AS `SoLuong_Nhap`, `hoa_don_mua_chi_tiet`.`GiaMua` AS `Gia_Mua` FROM `hoa_don_mua_chi_tiet` GROUP BY `hoa_don_mua_chi_tiet`.`MaHang` ;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `hang_hoa`
--
ALTER TABLE `hang_hoa`
  ADD PRIMARY KEY (`MaHang`),
  ADD KEY `foreign_XuatXuID` (`XuatXuID`);

--
-- Chỉ mục cho bảng `hoa_don_ban`
--
ALTER TABLE `hoa_don_ban`
  ADD PRIMARY KEY (`MaHoaDon`),
  ADD KEY `foreign_MaKhachHang` (`MaKhachHang`);

--
-- Chỉ mục cho bảng `hoa_don_ban_chi_tiet`
--
ALTER TABLE `hoa_don_ban_chi_tiet`
  ADD KEY `foreign_MaHoaDon` (`MaHoaDon`),
  ADD KEY `foreign_MaHang` (`MaHang`);

--
-- Chỉ mục cho bảng `hoa_don_mua`
--
ALTER TABLE `hoa_don_mua`
  ADD PRIMARY KEY (`MaHoaDon`);

--
-- Chỉ mục cho bảng `hoa_don_mua_chi_tiet`
--
ALTER TABLE `hoa_don_mua_chi_tiet`
  ADD KEY `foreign_MaHoaDon` (`MaHoaDon`),
  ADD KEY `foreign_MaHang` (`MaHang`);

--
-- Chỉ mục cho bảng `khach_hang`
--
ALTER TABLE `khach_hang`
  ADD PRIMARY KEY (`MaKhachHang`),
  ADD KEY `foreign_LoaiKhachHang` (`LoaiKhachHang`);

--
-- Chỉ mục cho bảng `loai_khach_hang`
--
ALTER TABLE `loai_khach_hang`
  ADD PRIMARY KEY (`MaLoai`);

--
-- Chỉ mục cho bảng `quoc_gia`
--
ALTER TABLE `quoc_gia`
  ADD PRIMARY KEY (`MaQuocGia`);

--
-- Chỉ mục cho bảng `test_table`
--
ALTER TABLE `test_table`
  ADD KEY `foreign_khach_hang` (`ma_khach_hang`);

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `hang_hoa`
--
ALTER TABLE `hang_hoa`
  ADD CONSTRAINT `hang_hoa_ibfk_1` FOREIGN KEY (`XuatXuID`) REFERENCES `quoc_gia` (`MaQuocGia`);

--
-- Các ràng buộc cho bảng `hoa_don_ban`
--
ALTER TABLE `hoa_don_ban`
  ADD CONSTRAINT `hoa_don_ban_ibfk_1` FOREIGN KEY (`MaKhachHang`) REFERENCES `khach_hang` (`MaKhachHang`);

--
-- Các ràng buộc cho bảng `hoa_don_ban_chi_tiet`
--
ALTER TABLE `hoa_don_ban_chi_tiet`
  ADD CONSTRAINT `hoa_don_ban_chi_tiet_ibfk_1` FOREIGN KEY (`MaHoaDon`) REFERENCES `hoa_don_ban` (`MaHoaDon`),
  ADD CONSTRAINT `hoa_don_ban_chi_tiet_ibfk_2` FOREIGN KEY (`MaHang`) REFERENCES `hang_hoa` (`MaHang`);

--
-- Các ràng buộc cho bảng `hoa_don_mua_chi_tiet`
--
ALTER TABLE `hoa_don_mua_chi_tiet`
  ADD CONSTRAINT `hoa_don_mua_chi_tiet_ibfk_1` FOREIGN KEY (`MaHoaDon`) REFERENCES `hoa_don_mua` (`MaHoaDon`),
  ADD CONSTRAINT `hoa_don_mua_chi_tiet_ibfk_2` FOREIGN KEY (`MaHang`) REFERENCES `hang_hoa` (`MaHang`);

--
-- Các ràng buộc cho bảng `khach_hang`
--
ALTER TABLE `khach_hang`
  ADD CONSTRAINT `khach_hang_ibfk_1` FOREIGN KEY (`LoaiKhachHang`) REFERENCES `loai_khach_hang` (`MaLoai`),
  ADD CONSTRAINT `khach_hang_ibfk_2` FOREIGN KEY (`LoaiKhachHang`) REFERENCES `loai_khach_hang` (`MaLoai`);

--
-- Các ràng buộc cho bảng `test_table`
--
ALTER TABLE `test_table`
  ADD CONSTRAINT `test_table_ibfk_1` FOREIGN KEY (`ma_khach_hang`) REFERENCES `khach_hang` (`MaKhachHang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
