-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th5 19, 2021 lúc 03:01 AM
-- Phiên bản máy phục vụ: 10.4.13-MariaDB
-- Phiên bản PHP: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `bookstore`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `book`
--

CREATE TABLE `book` (
  `bookId` int(11) NOT NULL,
  `bookName` varchar(150) NOT NULL,
  `bookDesc` varchar(1000) DEFAULT NULL,
  `bookImage` varchar(100) DEFAULT NULL,
  `bookPrice` float DEFAULT NULL,
  `bookAuthor` varchar(30) DEFAULT NULL,
  `dateCreated` date DEFAULT NULL,
  `bookApproved` bit(1) DEFAULT NULL,
  `dateApproved` date DEFAULT NULL COMMENT '\r\n',
  `subjectId` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `book`
--

INSERT INTO `book` (`bookId`, `bookName`, `bookDesc`, `bookImage`, `bookPrice`, `bookAuthor`, `dateCreated`, `bookApproved`, `dateApproved`, `subjectId`) VALUES
(1, 'Đắc Nhân Tâm', 'Sách nói về kỹ năng sống để thành công hơn trong cuộc sống', 'dacnhantam.jpg', 25000, 'Dale1', '2020-12-02', b'1', '2020-12-02', 'KT'),
(2, 'Cha giàu Cha nghèo', 'Sách nói về cách quản lý tài chính của Cha giàu và Cha nghèo', 'chagiauchangheo.jpg', 20000, 'Robert T.Kiyosaki', '2020-12-02', b'1', '2020-12-02', 'TH1'),
(3, 'Lập trình C++', 'Sách dạy lập trình ngôn ngữ C++', 'laptrinhc.jpg', 15000, 'Pham Van At', '2020-12-02', b'1', '2020-12-02', 'TH'),
(11, 'Tin học văn phòng', 'Sách dạy cách sử dụng phần mềm MS Word, Excel, PowerPoint', '', 35000, 'ABC', '2020-12-07', NULL, NULL, 'IT');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoidung`
--

CREATE TABLE `nguoidung` (
  `Id` int(11) NOT NULL,
  `TenDangNhap` varchar(50) NOT NULL,
  `MatKhau` varchar(50) NOT NULL,
  `HoTen` varchar(30) NOT NULL,
  `DienThoai` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `DiaChi` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `nguoidung`
--

INSERT INTO `nguoidung` (`Id`, `TenDangNhap`, `MatKhau`, `HoTen`, `DienThoai`, `Email`, `DiaChi`) VALUES
(1, 'phungnv', '12345', 'Nguyen Van Phung', '', '', ''),
(2, 'admin', '12345', 'Quan Tri He Thong', '', '', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `subject`
--

CREATE TABLE `subject` (
  `subjectId` varchar(10) NOT NULL,
  `subjectName` varchar(150) NOT NULL,
  `subjectDesc` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `subject`
--

INSERT INTO `subject` (`subjectId`, `subjectName`, `subjectDesc`) VALUES
('IT', 'Thieu nhi', NULL),
('KT1', 'Kinh te', NULL),
('TH', 'Tin hoc', 'Sach tin hoc'),
('TH1', 'Toan hoc', NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`bookId`);

--
-- Chỉ mục cho bảng `nguoidung`
--
ALTER TABLE `nguoidung`
  ADD PRIMARY KEY (`Id`);

--
-- Chỉ mục cho bảng `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subjectId`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `book`
--
ALTER TABLE `book`
  MODIFY `bookId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `nguoidung`
--
ALTER TABLE `nguoidung`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
