-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th5 18, 2021 lúc 01:31 AM
-- Phiên bản máy phục vụ: 10.4.13-MariaDB
-- Phiên bản PHP: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `quanly_nhanvien_luong`
--

DELIMITER $$
--
-- Thủ tục
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `capnhat_nhanvien` (`nv_code` VARCHAR(15), `ht` VARCHAR(50), `dc` VARCHAR(200), `mail` VARCHAR(50), `dt` VARCHAR(11))  begin
	update nhanvien set hoten=ht, diachi=dc, email=mail, dienthoai=dt where manv=nv_code;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `chitiet_nhanvien` (`ma` VARCHAR(15))  begin
	select * from nhanvien where manv=ma;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `lay_danhsach_nhanvien` ()  BEGIN
	SELECT MaNV, HoTen, DiaChi, Email, MaPhong FROM nhanvien;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `lay_danh_sach_nhanvien` ()  begin
	select * from nhanvien;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `nhanvien_phongban_luong` (`mp` VARCHAR(15), `minLuong` FLOAT, `ho_ten` VARCHAR(50))  begin
	select @ht := concat(ho_ten, '%');
    select @ht1 := concat('%', ho_ten);
    select @ma_phong := concat('%', mp, '%');
	select manv, hoten, diachi, email, (3500000*hsl.hesoluong + hsl.PhuCap) as Luong, pb.maphong, pb.Mota, hsl.hesoluong, hsl.PhuCap from nhanvien as nv inner join phongban as pb on nv.maphong=pb.MaPhong inner join hesoluong as hsl on nv.HeSoLuong=hsl.Id where (hoten like @ht or hoten like @ht1) and  pb.maphong like @ma_phong and ((3500000*hsl.hesoluong + hsl.PhuCap) > minLuong) order by (3500000*hsl.hesoluong + hsl.PhuCap);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `themmoi_nhanvien` (`ma` VARCHAR(15), `ht` VARCHAR(50), `dc` VARCHAR(300), `mail` VARCHAR(50), `dt` VARCHAR(11))  begin
	insert into nhanvien (manv, hoten, diachi, email, dienthoai) values (ma, ht, dc, mail, dt);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `them_moi_nhanvien` (`ma` VARCHAR(15), `ten` VARCHAR(50), `dc` VARCHAR(300), `mail` VARCHAR(50), `dt` VARCHAR(11))  BEGIN
	insert into nhanvien (MaNV, HoTen, DiaChi, Email, DienThoai) values (ma, ten, dc, mail, dt);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TongSo_NhanVien_PhongBan` (`mp` VARCHAR(15))  begin
	select maphong as PhongBan, count(*) as TongNhanVien from nhanvien where maphong=mp group by maphong;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `total_nhanvien` ()  begin
	select count(*) as TongSo_NhanVien from nhanvien;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `xoa_nhanvien` (`ma` VARCHAR(15))  begin
	delete from nhanvien where manv = ma;
end$$

--
-- Các hàm
--
CREATE DEFINER=`root`@`localhost` FUNCTION `check_color_code` (`color` VARCHAR(20)) RETURNS VARCHAR(10) CHARSET utf8mb4 begin
	set @result = case color
    when 'blk' then 'BLACK'
    when 'blu' then 'BLUE'
    when 'GRN' then 'GREEN'
    when 'GRY' then 'GRAY'
    when 'RD'  then 'RED'
    when 'YL' then 'YELLOW'
    else 'UNKNOWN'
    end;
    return @result;
end$$

CREATE DEFINER=`root`@`localhost` FUNCTION `count_nhanvien` () RETURNS INT(11) begin
	declare total int;
    set total = (select count(*) from nhanvien);
    return total;
end$$

CREATE DEFINER=`root`@`localhost` FUNCTION `count_nhanvien_on_phongban` (`phongban` VARCHAR(15)) RETURNS INT(11) begin
	declare total int;
    set total = (select count(*) from nhanvien where maphong=phongban);
    return total;
end$$

CREATE DEFINER=`root`@`localhost` FUNCTION `day_in_range` (`day` DATETIME, `num_day_before` FLOAT, `num_day_after` FLOAT) RETURNS TINYINT(1) BEGIN
	set @result = if(day > date_sub(now(), interval num_day_before day) and day < date_add(now(), interval num_day_after day), true, false);
    return @result;
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chamcong`
--

CREATE TABLE `chamcong` (
  `Id` int(11) NOT NULL,
  `NgayDiLam` date DEFAULT NULL,
  `ThoiGianVao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ThoiGianRa` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `MaNhanVien` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chucvu`
--

CREATE TABLE `chucvu` (
  `MaChucVu` varchar(15) NOT NULL,
  `TenChucVu` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hesoluong`
--

CREATE TABLE `hesoluong` (
  `Id` int(11) NOT NULL,
  `HeSoLuong` float DEFAULT NULL,
  `PhuCap` float DEFAULT NULL,
  `MoTa` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `hesoluong`
--

INSERT INTO `hesoluong` (`Id`, `HeSoLuong`, `PhuCap`, `MoTa`) VALUES
(1, 3, 0, NULL),
(2, 3.6, 0, NULL),
(3, 4, 0, NULL),
(4, 5, 0, NULL),
(5, 6, 200000, NULL),
(6, 7, 400000, NULL),
(7, 8, 500000, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhanvien`
--

CREATE TABLE `nhanvien` (
  `MaNV` varchar(15) NOT NULL,
  `HoTen` varchar(50) DEFAULT NULL,
  `GioiTinh` varchar(10) DEFAULT NULL,
  `NgaySinh` date DEFAULT NULL,
  `DienThoai` varchar(11) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `DiaChi` varchar(300) DEFAULT NULL,
  `CMND` varchar(10) DEFAULT NULL,
  `NgayCap` date DEFAULT NULL,
  `NoiCap` varchar(300) DEFAULT NULL,
  `MaPhong` varchar(15) DEFAULT NULL,
  `HeSoLuong` float DEFAULT NULL,
  `ChucVu` varchar(15) DEFAULT NULL,
  `luong` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `nhanvien`
--

INSERT INTO `nhanvien` (`MaNV`, `HoTen`, `GioiTinh`, `NgaySinh`, `DienThoai`, `Email`, `DiaChi`, `CMND`, `NgayCap`, `NoiCap`, `MaPhong`, `HeSoLuong`, `ChucVu`, `luong`) VALUES
('SF001', 'Trần Hoài Nam', NULL, NULL, '0966742886', 'Thetrueman87@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'CNTT', 1, NULL, 3500000),
('SF002', 'Lê Tú Phương', NULL, NULL, '0385322134', 'tu12234@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'DT', 2, NULL, 7000000),
('SF003', 'Nguyễn Chí Cao', NULL, NULL, '925011593', 'heavygobl@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'KT', 4, NULL, 14000000),
('SF004', 'Nguyễn Văn Dũng', NULL, NULL, '966129802', 'dnv1110@gmail.com', 'Nam Định', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF005', 'Võ Đức Minh', NULL, NULL, '393869432', 'minhvd9@gmail.com', 'Nam Định', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF006', 'Lê Đức Thắng', NULL, NULL, '988551556', 'leductha@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'DT', 5, NULL, 17500000),
('SF007', 'Trương Đình Hưng', NULL, NULL, '986393245', 'tdhung21@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'DT', 4, NULL, 14000000),
('SF008', 'Nguyễn Văn Long', NULL, NULL, '988890869', 'vlong25@gmail.com', 'Hà Nam', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF009', 'Nguyễn Huy Hoàng', NULL, NULL, '944236125', 'Monkey272@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 6, NULL, 21200000),
('SF010', 'Kiều Thị Quỳnh', NULL, NULL, '979359689', 'quynhtk@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'DT', 7, NULL, 24900000),
('SF011', 'Nguyễn Hiếu Minh', NULL, NULL, '838382256', 'Minh2001@gmail.com', 'Thanh Hóa', NULL, NULL, NULL, 'DT', 3, NULL, 10500000),
('SF012', 'Nguyễn Hoàng Nam', NULL, NULL, '352479126', 'sterkenburger9@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'DT', 4, NULL, 14000000),
('SF013', 'Nguyễn Văn Đạt', NULL, NULL, '865403569', 'thanhdatb@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF014', 'Nguyễn Thị Ngọc Hoa', NULL, NULL, '363519065', 'Ngochoa216@gmail.com', 'Bắc Ninh', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF015', 'Phạm Trọng Minh', NULL, NULL, '983243389', 'phantrongminh12@gmail.com', 'Hưng Yên', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF016', 'Vũ Huy Thành', NULL, NULL, '901535433', 'vhthanh@gmail.com ', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF017', 'Phùng Thị Kim Ngân', NULL, NULL, '348413788', 'phungthikimngan@gmail.com', 'Hưng Yên', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF018', 'Phạm Văn Tư', NULL, NULL, '795253418', 'phamtu@gmail.com', 'Bắc Ninh', NULL, NULL, NULL, 'CNTT', 1, NULL, 3500000),
('SF019', 'Nguyễn Trọng Dũng', NULL, NULL, '965364629', 'dung200103@gmail.com', 'Hải Phòng', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF020', 'Phạm Văn Tuấn', NULL, NULL, '962174905', 'phamvantuan1@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'KT', 3, NULL, 10500000),
('SF021', 'Đỗ Hùng Cường', NULL, NULL, '832230556', 'dohungcuong16032@gmail.com', 'Hà Nam', NULL, NULL, NULL, 'DT', 3, NULL, 10500000),
('SF022', 'Nguyễn Đức Hoài', NULL, NULL, '762092056', 'hoaisim@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'DT', 5, NULL, 17500000),
('SF023', 'Trần Thị Vân', NULL, NULL, '985227368', 'tranvan@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 4, NULL, 14000000),
('SF024', 'Lương Công Thành', NULL, NULL, '372241738', 'luongthanh@gmail.com', 'Thanh Hóa', NULL, NULL, NULL, 'KT', 1, NULL, 3500000),
('SF025', 'Vũ Huy Nhật Minh', NULL, NULL, '904181328', 'nminhstick@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF026', 'Đỗ Việt Anh', NULL, NULL, '346992258', 'Dovietanh@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'CNTT', 1, NULL, 3500000),
('SF027', 'Nguyễn Đăng Trường', NULL, NULL, '927081089', 'truongnd@gmail.com', 'Bắc Ninh', NULL, NULL, NULL, 'CNTT', 4, NULL, 14000000),
('SF028', 'Nguyễn Quốc Anh', NULL, NULL, '977538655', 'quocanhbnp@gmail.com', 'Hải Dương', NULL, NULL, NULL, 'KD', 1, NULL, 3500000),
('SF029', 'Bùi Anh Tuấn', NULL, NULL, '343484443', 'tuangon@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'KD', 5, NULL, 17500000),
('SF030', 'Nguyễn Xuân Sơn', NULL, NULL, '936814456', 'Nguyenxuanson@gmail.com', 'Hưng Yên', NULL, NULL, NULL, 'KD', 4, NULL, 14000000),
('SF031', 'Trịnh Khang Ninh', NULL, NULL, '375487045', 'khangninh@gmail.com', 'Hải Dương', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF032', 'Nguyễn Đức Thịnh', NULL, NULL, '398121589', 'nguyenducthinh@gmail.com', 'Hải Phòng', NULL, NULL, NULL, 'CNTT', 6, NULL, 21200000),
('SF033', 'Hoàng Văn Tùng', NULL, NULL, '336911015', 'tunghv15@gmail.com', 'Hải Dương', NULL, NULL, NULL, 'KD', 7, NULL, 24900000),
('SF034', 'Nguyễn Ngọc Thức', NULL, NULL, '785719958', 'ngocthucmo@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 4, NULL, 14000000),
('SF035', 'Vũ Hạnh Dung', NULL, NULL, '941170085', 'hanhdung@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'KD', 8, NULL, 28500000),
('SF036', 'Vũ Việt Hoàng', NULL, NULL, '393004656', 'shintheman@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'CNTT', 1, NULL, 3500000),
('SF037', 'Đặng Đình Hưng', NULL, NULL, '338700554', 'hungdd@gmail.com', 'Bắc Ninh', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF038', 'Nguyễn Mạnh Hùng', NULL, NULL, '849888464', 'hung08498@gmail.com', 'Hải Dương', NULL, NULL, NULL, 'KD', 1, NULL, 3500000),
('SF039', 'Phùng Lê Phương Anh', NULL, NULL, '936424586', 'planh@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF040', 'Hoàng Đức Chiến', NULL, NULL, '977373569', 'chienhoang@gmail.com', 'Hưng Yên', NULL, NULL, NULL, 'KT', 4, NULL, 14000000),
('SF041', 'Đinh Đồng Tuấn', NULL, NULL, '962783856', 'tuan@benhvienhungviet.vn', 'Hải Dương', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF042', 'Tô Văn Dũng', NULL, NULL, '348201207', 'dungtv09@gmail.com', 'Hải Phòng', NULL, NULL, NULL, 'KD', 3, NULL, 10500000),
('SF043', 'Bùi Thị Phương', NULL, NULL, '981788169', 'buithiphuongtcdn@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF044', 'Đoàn Đức Vượng', NULL, NULL, '\'0975515625', 'ducvuong@gmail.com', 'Hà Nam', NULL, NULL, NULL, 'KD', 5, NULL, 17500000),
('SF045', 'Nguyễn Thế Phúc', NULL, NULL, '829128866', 'en.deathrav@gmail.com', 'Hồ Chí Minh', NULL, NULL, NULL, 'KD', 4, NULL, 14000000),
('SF046', 'Nguyễn thanh Lâm', NULL, NULL, '981175986', 'thanhlam@gmail.com', 'Hồ Chí Minh', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF047', 'Le Thi Thu Minh', NULL, NULL, '0988123456', 'thuminh@gmail.com', 'Hai Phong', NULL, NULL, NULL, 'KD', NULL, NULL, NULL),
('SF048', 'Nguyễn Văn Phụng', NULL, NULL, '0356078993', 'phungalien89@gmail.com', 'Quảng Ngãi', NULL, NULL, NULL, 'CNTT', NULL, NULL, NULL),
('SF049', 'Nguyễn Thị Thùy Dung', NULL, NULL, '0955114677', 'dung.nguyenthithuy@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'CNTT', NULL, NULL, NULL),
('SF050', 'Nguyễn Thị Hồng Nhung', NULL, NULL, '0960411486', 'nhung.nguyenthihong@gmail.com', 'Lào Cai', NULL, NULL, NULL, 'CNTT', NULL, NULL, NULL),
('SF051', 'Phùng Thị Thanh', NULL, NULL, '0960411486', 'thanh.phungthi@gmail.com', 'Vĩnh Phúc', NULL, NULL, NULL, 'CNTT', NULL, NULL, NULL),
('SF052', 'Đặng Thị Dung', NULL, NULL, '0953780604', 'dung.dangthi@gmail.com', 'Hà Nội', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('SF053', 'Trần Minh', NULL, NULL, '0938456309', 'minh.tran@gmail.com', 'Hải Dương', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Bẫy `nhanvien`
--
DELIMITER $$
CREATE TRIGGER `auto_nhatky` BEFORE INSERT ON `nhanvien` FOR EACH ROW begin
	insert into nhatky (noi_dung, hanh_dong) values (concat('Thêm mới nhân viên có mã ', new.manv, ', Họ tên: ', new.hoten, ', Địa chỉ: ', new.diachi, ', Email: ', new.email), 'Thêm mới');
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhanvien1`
--

CREATE TABLE `nhanvien1` (
  `MaNV` varchar(15) DEFAULT NULL,
  `HoTen` varchar(50) DEFAULT NULL,
  `DienThoai` varchar(11) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `DiaChi` varchar(300) DEFAULT NULL,
  `HeSoLuong` float DEFAULT NULL,
  `MaPhong` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `nhanvien1`
--

INSERT INTO `nhanvien1` (`MaNV`, `HoTen`, `DienThoai`, `Email`, `DiaChi`, `HeSoLuong`, `MaPhong`) VALUES
('SF001', 'Trần Hoài Nam', '966742885', 'Thetrueman87@gmail.com', 'Thái Bình', 1, 'CNTT'),
('SF002', 'Lê Phương Tú', '385322134', 'tu12234@gmail.com', 'Hà Nội', 2, 'DT'),
('SF003', 'Nguyễn Chí Cao', '925011593', 'heavygobl@gmail.com', 'Hà Nội', 4, 'KT'),
('SF004', 'Nguyễn Văn Dũng', '966129802', 'dnv1110@gmail.com', 'Nam Định', 3, 'CNTT'),
('SF005', 'Võ Đức Minh', '393869432', 'minhvd9@gmail.com', 'Nam Định', 1, 'DT'),
('SF006', 'Lê Đức Thắng', '988551556', 'leductha@gmail.com', 'Thái Bình', 5, 'DT'),
('SF007', 'Trương Đình Hưng', '986393245', 'tdhung21@gmail.com', 'Thái Bình', 4, 'DT'),
('SF008', 'Nguyễn Văn Long', '988890869', 'vlong25@gmail.com', 'Hà Nam', 1, 'DT'),
('SF009', 'Nguyễn Huy Hoàng', '944236125', 'Monkey272@gmail.com', 'Hà Nội', 6, 'CNTT'),
('SF010', 'Kiều Thị Quỳnh', '979359689', 'quynhtk@gmail.com', 'Hà Nội', 7, 'DT'),
('SF011', 'Nguyễn Hiếu Minh', '838382256', 'Minh2001@gmail.com', 'Thanh Hóa', 3, 'DT'),
('SF012', 'Nguyễn Hoàng Nam', '352479126', 'sterkenburger9@gmail.com', 'Nghệ An', 4, 'DT'),
('SF013', 'Nguyễn Văn Đạt ', '865403569', 'thanhdatb@gmail.com', 'Nghệ An', 3, 'CNTT'),
('SF014', 'Nguyễn Thị Ngọc Hoa', '363519065', 'Ngochoa216@gmail.com', 'Bắc Ninh', 3, 'CNTT'),
('SF015', 'Phạm Trọng Minh', '983243389', 'phantrongminh12@gmail.com', 'Hưng Yên', 1, 'DT'),
('SF016', 'Vũ Huy Thành', '901535433', 'vhthanh@gmail.com ', 'Hà Nội', 3, 'CNTT'),
('SF017', 'Phùng Thị Kim Ngân', '348413788', 'phungthikimngan@gmail.com', 'Hưng Yên', 3, 'DT'),
('SF018', 'Phạm Văn Tư', '795253418', 'phamtu@gmail.com', 'Bắc Ninh', 1, 'CNTT'),
('SF019', 'Nguyễn Trọng Dũng', '965364629', 'dung200103@gmail.com', 'Hải Phòng', 3, 'CNTT'),
('SF020', 'Phạm Văn Tuấn', '962174905', 'phamvantuan1@gmail.com', 'Thái Bình', 3, 'KT'),
('SF021', 'Đỗ Hùng Cường', '832230556', 'dohungcuong16032@gmail.com', 'Hà Nam', 3, 'DT'),
('SF022', 'Nguyễn Đức Hoài', '762092056', 'hoaisim@gmail.com', 'Hà Nội', 5, 'DT'),
('SF023', 'Trần Thị Vân', '985227368', 'tranvan@gmail.com', 'Hà Nội', 4, 'CNTT'),
('SF024', 'Lương Công Thành', '372241738', 'luongthanh@gmail.com', 'Thanh Hóa', 1, 'KT'),
('SF025', 'Vũ Huy Nhật Minh', '904181328', 'nminhstick@gmail.com', 'Nghệ An', 3, 'CNTT'),
('SF026', 'Đỗ Việt Anh', '346992258', 'Dovietanh@gmail.com', 'Nghệ An', 1, 'CNTT'),
('SF027', 'Nguyễn Đăng Trường', '927081089', 'truongnd@gmail.com', 'Bắc Ninh', 4, 'CNTT'),
('SF028', 'Nguyễn Quốc Anh', '977538655', 'quocanhbnp@gmail.com', 'Hải Dương', 1, 'KD'),
('SF029', 'Bùi Anh Tuấn', '343484443', 'tuangon@gmail.com', 'Hà Nội', 5, 'KD'),
('SF030', 'Nguyễn Xuân Sơn', '936814456', 'Nguyenxuanson@gmail.com', 'Hưng Yên', 4, 'KD'),
('SF031', 'Trịnh Khang Ninh', '375487045', 'khangninh@gmail.com', 'Hải Dương', 3, 'CNTT'),
('SF032', 'Nguyễn Đức Thịnh', '398121589', 'nguyenducthinh@gmail.com', 'Hải Phòng', 6, 'CNTT'),
('SF033', 'Hoàng Văn Tùng', '336911015', 'tunghv15@gmail.com', 'Hải Dương', 7, 'KD'),
('SF034', 'Nguyễn Ngọc Thức', '785719958', 'ngocthucmo@gmail.com', 'Hà Nội', 4, 'CNTT'),
('SF035', 'Vũ Hạnh Dung', '941170085', 'hanhdung@gmail.com', 'Nghệ An', 8, 'KD'),
('SF036', 'Vũ Việt Hoàng', '393004656', 'shintheman@gmail.com', 'Nghệ An', 1, 'CNTT'),
('SF037', 'Đặng Đình Hưng', '338700554', 'hungdd@gmail.com', 'Bắc Ninh', 3, 'CNTT'),
('SF038', 'Nguyễn Mạnh Hùng', '849888464', 'hung08498@gmail.com', 'Hải Dương', 1, 'KD'),
('SF039', 'Phùng Lê Phương Anh', '936424586', 'planh@gmail.com', 'Hà Nội', 3, 'DT'),
('SF040', 'Hoàng Đức Chiến', '977373569', 'chienhoang@gmail.com', 'Hưng Yên', 4, 'KT'),
('SF041', 'Đinh Đồng Tuấn', '962783856', 'tuan@benhvienhungviet.vn', 'Hải Dương', 3, 'CNTT'),
('SF042', 'Tô Văn Dũng', '348201207', 'dungtv09@gmail.com', 'Hải Phòng', 3, 'KD'),
('SF043', 'Bùi Thị Phương', '981788169', 'buithiphuongtcdn@gmail.com', 'Thái Bình', 1, 'DT'),
('SF044', 'Đoàn Đức Vượng', '\'0975515625', 'ducvuong@gmail.com', 'Hà Nam', 5, 'KD'),
('SF045', 'Nguyễn Thế Phúc', '829128866', 'en.deathrav@gmail.com', 'Hồ Chí Minh', 4, 'KD'),
('SF046', 'Nguyễn thanh Lâm', '981175986', 'thanhlam@gmail.com', 'Hồ Chí Minh', 1, 'DT');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhanvien2`
--

CREATE TABLE `nhanvien2` (
  `MaNV` varchar(15) NOT NULL,
  `HoTen` varchar(50) DEFAULT NULL,
  `GioiTinh` varchar(10) DEFAULT NULL,
  `NgaySinh` date DEFAULT NULL,
  `DienThoai` varchar(11) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `DiaChi` varchar(300) DEFAULT NULL,
  `CMND` varchar(10) DEFAULT NULL,
  `NgayCap` date DEFAULT NULL,
  `NoiCap` varchar(300) DEFAULT NULL,
  `MaPhong` varchar(15) DEFAULT NULL,
  `HeSoLuong` float DEFAULT NULL,
  `ChucVu` varchar(15) DEFAULT NULL,
  `luong` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `nhanvien2`
--

INSERT INTO `nhanvien2` (`MaNV`, `HoTen`, `GioiTinh`, `NgaySinh`, `DienThoai`, `Email`, `DiaChi`, `CMND`, `NgayCap`, `NoiCap`, `MaPhong`, `HeSoLuong`, `ChucVu`, `luong`) VALUES
('SF001', 'Trần Hoài Nam', NULL, NULL, '966742885', 'Thetrueman87@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'CNTT', 1, NULL, 3500000),
('SF002', 'Lê Phương Tú', NULL, NULL, '385322134', 'tu12234@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'DT', 2, NULL, 7000000),
('SF003', 'Nguyễn Chí Cao', NULL, NULL, '925011593', 'heavygobl@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'KT', 4, NULL, 14000000),
('SF004', 'Nguyễn Văn Dũng', NULL, NULL, '966129802', 'dnv1110@gmail.com', 'Nam Định', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF005', 'Võ Đức Minh', NULL, NULL, '393869432', 'minhvd9@gmail.com', 'Nam Định', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF006', 'Lê Đức Thắng', NULL, NULL, '988551556', 'leductha@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'DT', 5, NULL, 17500000),
('SF007', 'Trương Đình Hưng', NULL, NULL, '986393245', 'tdhung21@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'DT', 4, NULL, 14000000),
('SF008', 'Nguyễn Văn Long', NULL, NULL, '988890869', 'vlong25@gmail.com', 'Hà Nam', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF009', 'Nguyễn Huy Hoàng', NULL, NULL, '944236125', 'Monkey272@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 6, NULL, 21200000),
('SF010', 'Kiều Thị Quỳnh', NULL, NULL, '979359689', 'quynhtk@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'DT', 7, NULL, 24900000),
('SF011', 'Nguyễn Hiếu Minh', NULL, NULL, '838382256', 'Minh2001@gmail.com', 'Thanh Hóa', NULL, NULL, NULL, 'DT', 3, NULL, 10500000),
('SF012', 'Nguyễn Hoàng Nam', NULL, NULL, '352479126', 'sterkenburger9@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'DT', 4, NULL, 14000000),
('SF013', 'Nguyễn Văn Đạt', NULL, NULL, '865403569', 'thanhdatb@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF014', 'Nguyễn Thị Ngọc Hoa', NULL, NULL, '363519065', 'Ngochoa216@gmail.com', 'Bắc Ninh', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF015', 'Phạm Trọng Minh', NULL, NULL, '983243389', 'phantrongminh12@gmail.com', 'Hưng Yên', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF016', 'Vũ Huy Thành', NULL, NULL, '901535433', 'vhthanh@gmail.com ', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF017', 'Phùng Thị Kim Ngân', NULL, NULL, '348413788', 'phungthikimngan@gmail.com', 'Hưng Yên', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF018', 'Phạm Văn Tư', NULL, NULL, '795253418', 'phamtu@gmail.com', 'Bắc Ninh', NULL, NULL, NULL, 'CNTT', 1, NULL, 3500000),
('SF019', 'Nguyễn Trọng Dũng', NULL, NULL, '965364629', 'dung200103@gmail.com', 'Hải Phòng', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF020', 'Phạm Văn Tuấn', NULL, NULL, '962174905', 'phamvantuan1@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'KT', 3, NULL, 10500000),
('SF021', 'Đỗ Hùng Cường', NULL, NULL, '832230556', 'dohungcuong16032@gmail.com', 'Hà Nam', NULL, NULL, NULL, 'DT', 3, NULL, 10500000),
('SF022', 'Nguyễn Đức Hoài', NULL, NULL, '762092056', 'hoaisim@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'DT', 5, NULL, 17500000),
('SF023', 'Trần Thị Vân', NULL, NULL, '985227368', 'tranvan@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 4, NULL, 14000000),
('SF024', 'Lương Công Thành', NULL, NULL, '372241738', 'luongthanh@gmail.com', 'Thanh Hóa', NULL, NULL, NULL, 'KT', 1, NULL, 3500000),
('SF025', 'Vũ Huy Nhật Minh', NULL, NULL, '904181328', 'nminhstick@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF026', 'Đỗ Việt Anh', NULL, NULL, '346992258', 'Dovietanh@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'CNTT', 1, NULL, 3500000),
('SF027', 'Nguyễn Đăng Trường', NULL, NULL, '927081089', 'truongnd@gmail.com', 'Bắc Ninh', NULL, NULL, NULL, 'CNTT', 4, NULL, 14000000),
('SF028', 'Nguyễn Quốc Anh', NULL, NULL, '977538655', 'quocanhbnp@gmail.com', 'Hải Dương', NULL, NULL, NULL, 'KD', 1, NULL, 3500000),
('SF029', 'Bùi Anh Tuấn', NULL, NULL, '343484443', 'tuangon@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'KD', 5, NULL, 17500000),
('SF030', 'Nguyễn Xuân Sơn', NULL, NULL, '936814456', 'Nguyenxuanson@gmail.com', 'Hưng Yên', NULL, NULL, NULL, 'KD', 4, NULL, 14000000),
('SF031', 'Trịnh Khang Ninh', NULL, NULL, '375487045', 'khangninh@gmail.com', 'Hải Dương', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF032', 'Nguyễn Đức Thịnh', NULL, NULL, '398121589', 'nguyenducthinh@gmail.com', 'Hải Phòng', NULL, NULL, NULL, 'CNTT', 6, NULL, 21200000),
('SF033', 'Hoàng Văn Tùng', NULL, NULL, '336911015', 'tunghv15@gmail.com', 'Hải Dương', NULL, NULL, NULL, 'KD', 7, NULL, 24900000),
('SF034', 'Nguyễn Ngọc Thức', NULL, NULL, '785719958', 'ngocthucmo@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 4, NULL, 14000000),
('SF035', 'Vũ Hạnh Dung', NULL, NULL, '941170085', 'hanhdung@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'KD', 8, NULL, 28500000),
('SF036', 'Vũ Việt Hoàng', NULL, NULL, '393004656', 'shintheman@gmail.com', 'Nghệ An', NULL, NULL, NULL, 'CNTT', 1, NULL, 3500000),
('SF037', 'Đặng Đình Hưng', NULL, NULL, '338700554', 'hungdd@gmail.com', 'Bắc Ninh', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF038', 'Nguyễn Mạnh Hùng', NULL, NULL, '849888464', 'hung08498@gmail.com', 'Hải Dương', NULL, NULL, NULL, 'KD', 1, NULL, 3500000),
('SF039', 'Phùng Lê Phương Anh', NULL, NULL, '936424586', 'planh@gmail.com', 'Hà Nội', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF040', 'Hoàng Đức Chiến', NULL, NULL, '977373569', 'chienhoang@gmail.com', 'Hưng Yên', NULL, NULL, NULL, 'KT', 4, NULL, 14000000),
('SF041', 'Đinh Đồng Tuấn', NULL, NULL, '962783856', 'tuan@benhvienhungviet.vn', 'Hải Dương', NULL, NULL, NULL, 'CNTT', 3, NULL, 10500000),
('SF042', 'Tô Văn Dũng', NULL, NULL, '348201207', 'dungtv09@gmail.com', 'Hải Phòng', NULL, NULL, NULL, 'KD', 3, NULL, 10500000),
('SF043', 'Bùi Thị Phương', NULL, NULL, '981788169', 'buithiphuongtcdn@gmail.com', 'Thái Bình', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF044', 'Đoàn Đức Vượng', NULL, NULL, '\'0975515625', 'ducvuong@gmail.com', 'Hà Nam', NULL, NULL, NULL, 'KD', 5, NULL, 17500000),
('SF045', 'Nguyễn Thế Phúc', NULL, NULL, '829128866', 'en.deathrav@gmail.com', 'Hồ Chí Minh', NULL, NULL, NULL, 'KD', 4, NULL, 14000000),
('SF046', 'Nguyễn thanh Lâm', NULL, NULL, '981175986', 'thanhlam@gmail.com', 'Hồ Chí Minh', NULL, NULL, NULL, 'DT', 1, NULL, 3500000),
('SF047', 'Le Thi Thu Minh', NULL, NULL, '0988123456', 'thuminh@gmail.com', 'Hai Phong', NULL, NULL, NULL, 'KD', NULL, NULL, NULL),
('SF048', 'Nguyễn Văn Phụng', NULL, NULL, '0356078993', 'phungalien89@gmail.com', 'Quảng Ngãi', NULL, NULL, NULL, 'CNTT', NULL, NULL, NULL),
('SF049', 'Nguyễn Văn Phụng', NULL, NULL, '0356078993', 'phungalien89@gmail.com', 'Quảng Ngãi', NULL, NULL, NULL, 'CNTT', NULL, NULL, NULL),
('SF050', 'Nguyễn Văn Phụng', NULL, NULL, '0356078993', 'phungalien89@gmail.com', 'Quảng Ngãi', NULL, NULL, NULL, 'CNTT', NULL, NULL, NULL),
('SF051', 'Nguyễn Văn Phụng', NULL, NULL, '0356078993', 'phungalien89@gmail.com', 'Quảng Ngãi', NULL, NULL, NULL, 'CNTT', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhatky`
--

CREATE TABLE `nhatky` (
  `id` int(11) NOT NULL,
  `noi_dung` varchar(1000) DEFAULT NULL,
  `hanh_dong` varchar(20) DEFAULT NULL,
  `ngay_tao` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `nhatky`
--

INSERT INTO `nhatky` (`id`, `noi_dung`, `hanh_dong`, `ngay_tao`) VALUES
(2, 'Thêm mới nhân viên có mã SF052, Họ tên: Trần Trọng Nghĩa, Địa chỉ: Hải Dương, Email: nghia.trantrong@gmail.com', 'Thêm mới', '2021-03-26 20:39:57'),
(9, 'Thêm mới nhân viên có mã SF053, Họ tên: Trần Trọng Minh, Địa chỉ: Hải Dương, Email: minh.trantrong@gmail.com', 'Thêm mới', '2021-03-26 20:41:58'),
(10, 'Thêm mới nhân viên có mã SF054, Họ tên: Đặng Thị Dung, Địa chỉ: Hà Nội, Email: dung.dangthi@gmail.com', 'Thêm mới', '2021-03-29 11:16:01'),
(11, 'Thêm mới nhân viên có mã SF052, Họ tên: Đặng Thị Dung, Địa chỉ: Hà Nội, Email: dung.dangthi@gmail.com', 'Thêm mới', '2021-03-29 11:16:46'),
(12, 'Thêm mới nhân viên có mã SF0100, Họ tên: Anderson Nguyen Phung, Địa chỉ: Quang Ngai, Email: phungalien89@gmail.com', 'Thêm mới', '2021-05-14 19:35:44');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phongban`
--

CREATE TABLE `phongban` (
  `MaPhong` varchar(15) NOT NULL,
  `TenPhong` varchar(100) DEFAULT NULL,
  `Mota` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `phongban`
--

INSERT INTO `phongban` (`MaPhong`, `TenPhong`, `Mota`) VALUES
('CNTT', 'Cong nghe thong tin', ''),
('KD', 'Kinh doanh', ''),
('KT', 'Ke Toan', ''),
('TT', 'Truyen thong', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc đóng vai cho view `view_bangluong`
-- (See below for the actual view)
--
CREATE TABLE `view_bangluong` (
`manv` varchar(15)
,`hoten` varchar(50)
,`diachi` varchar(300)
,`email` varchar(50)
,`maphong` varchar(15)
,`tenphong` varchar(100)
,`tong_luong` double
);

-- --------------------------------------------------------

--
-- Cấu trúc cho view `view_bangluong`
--
DROP TABLE IF EXISTS `view_bangluong`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_bangluong`  AS SELECT `nv`.`MaNV` AS `manv`, `nv`.`HoTen` AS `hoten`, `nv`.`DiaChi` AS `diachi`, `nv`.`Email` AS `email`, `pb`.`MaPhong` AS `maphong`, `pb`.`TenPhong` AS `tenphong`, `hsl`.`HeSoLuong`* 3500000 + `hsl`.`PhuCap` AS `tong_luong` FROM ((`nhanvien` `nv` join `phongban` `pb` on(`nv`.`MaPhong` = `pb`.`MaPhong`)) join `hesoluong` `hsl` on(`nv`.`HeSoLuong` = `hsl`.`Id`)) ;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chamcong`
--
ALTER TABLE `chamcong`
  ADD PRIMARY KEY (`Id`);

--
-- Chỉ mục cho bảng `chucvu`
--
ALTER TABLE `chucvu`
  ADD PRIMARY KEY (`MaChucVu`);

--
-- Chỉ mục cho bảng `hesoluong`
--
ALTER TABLE `hesoluong`
  ADD PRIMARY KEY (`Id`);

--
-- Chỉ mục cho bảng `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD PRIMARY KEY (`MaNV`),
  ADD KEY `manv_index` (`MaNV`),
  ADD KEY `idx_email` (`Email`);
ALTER TABLE `nhanvien` ADD FULLTEXT KEY `HoTen` (`HoTen`);

--
-- Chỉ mục cho bảng `nhanvien2`
--
ALTER TABLE `nhanvien2`
  ADD PRIMARY KEY (`MaNV`),
  ADD KEY `manv_index` (`MaNV`);

--
-- Chỉ mục cho bảng `nhatky`
--
ALTER TABLE `nhatky`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `phongban`
--
ALTER TABLE `phongban`
  ADD PRIMARY KEY (`MaPhong`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `chamcong`
--
ALTER TABLE `chamcong`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `hesoluong`
--
ALTER TABLE `hesoluong`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `nhatky`
--
ALTER TABLE `nhatky`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
